# Claude Blind Mutation Pack Round 2 Handoff

## Verify before authoring

- Validator version: `1.0.1`
- Validator SHA-256: `3d7c0a5e02a12f929efae53ec1d0189de38da8aca1c93c866e35d9de4e1fc5a0`
- Target canonical ZIP SHA-256: `22b99b85df79bebc2ffcb7ceee0c721edfaf404af1fd2f14770c3a0750b2055e`
- Target content-root SHA-256: `bb742f07e25921f84aa5e5bc687ce37f1bc414b2a89e80a34015da60e3813f0b`

## Round 1 outcome

Round 1 detected 23 of 24 mutations. One approved projection-parity property was missed and the validator was repaired and refrozen. Round 2 must be a completely fresh pack.

## Task

Create Blind Mutation Pack Round 2 against the refrozen validator and the same pinned canonical target.

Do not reuse Round 1 mutation IDs, selectors, target records, changed values or implementations. Do not inspect the internal known-mutation suite. Do not disclose mutation targets in chat.

The pack must include structural, projection and structurally valid semantic mutations. It must challenge at least:

- full canonical-to-workbook projection parity;
- lineage and split behavior preservation;
- gate/artifact executability;
- revalidation honesty;
- journey provability;
- M4/M5a printing boundary;
- M5a/M5b authority and DNS/TLS boundary;
- future-domain negative fencing;
- private-key custody;
- stopping-rule strength;
- same-QR fail-safe behavior.

Produce one standard-library runner that operates on fresh temporary copies, invokes the refrozen validator unchanged and records expected versus actual results.

Do not create Package M0, M0R, a database or application code.
