#!/usr/bin/env python3
from __future__ import annotations
import json,sys,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'validator'))
from forbidden_scan import prepare,scan_text
rules=json.loads((ROOT/'validator/forbidden_surface_rules.json').read_text())
req=json.loads((Path(sys.argv[1])/'canonical/reconciled_requirements.json').read_text())['active_requirements']
active={r['id'] for r in req};p=prepare(rules,active)
results=[]
for mid,rid,text in [('V208-M01', 'FR-CSH-003', 'No inventory module is present, but provide payroll management for staff.'), ('V208-M02', 'FR-CSH-003', 'Do not prevent managers from enabling payroll records.'), ('V208-M03', 'FR-CSH-003', 'Provide ingredient variance calculations for kitchen production.'), ('V208-M04', 'FR-OPS-018', 'Provide consumable inventory management for the outlet.'), ('V208-M05', 'FR-CSH-003', 'No inventory module is present. Provide payroll management for staff.'), ('V208-M06', 'FR-CSH-003', 'No inventory module is present; however enable workforce records.'), ('V208-M07', 'FR-CSH-003', 'Allow denomination changes and provide payroll management.'), ('V208-M08', 'FR-OPS-018', 'Do not prohibit inventory management for consumables.'), ('V208-M09', 'FR-TST-004B', 'Enable supplier runtime for purchasing.'), ('V208-M10', 'FR-SEC-010B', 'Record employee attendance and payroll history.')]:
 f=scan_text(rid,text,rules,p);results.append({'mutation_id':mid,'class':'semantic','text':text,'detected':bool(f),'failure_codes':['FORBIDDEN_SURFACE_RULE'] if f else []})
permitted=[]
for term,rid,text in [('delivery', 'FR-INT-004', 'Configuration delivery between the cloud and outlet node is versioned.'), ('inventory', 'FR-OPS-018', 'Maintain an outlet inventory of continuity nodes, routers, terminals and printers.'), ('loyalty', 'FR-AUTH-003', 'Create a guest session without phone, email or loyalty registration.'), ('costing', 'FR-RCP-008A', 'Customer-visible content is separate from confidential future costing.'), ('variance', 'FR-CSH-003', 'Record cash drawer denomination variance at close.'), ('export', 'FR-OPS-015', 'Provide a tenant data export operation for administration.'), ('accounting', 'FR-PAY-010A', 'Payment events expose documented Phase 2 accounting extension events, with no consumer in Phase 1.'), ('workforce', 'FR-SEC-010B', 'Employee data classification is documented in the Phase 2 workforce extension contract only.')]:
 f=scan_text(rid,text,rules,p);permitted.append({'term':term,'requirement_id':rid,'example':text,'passed':not f,'findings':f})
baseline=subprocess.run([sys.executable,str(ROOT/'validator/validate_hospitality_os.py'),sys.argv[1]],capture_output=True,text=True)
report={'validator_version':'1.0.5','baseline_passed':baseline.returncode==0,'mutation_count':len(results),'detected_count':sum(x['detected'] for x in results),'permitted_sense_count':len(permitted),'permitted_sense_passed':sum(x['passed'] for x in permitted),'results':results,'permitted_senses':permitted}
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['baseline_passed'] and report['detected_count']==len(results) and report['permitted_sense_passed']==len(permitted) else 1)
