# Hospitality OS Validator Freeze v1.0.5

This standard-library validator is pinned to canonical source v0.1.4. It adds occurrence-linked forbidden-surface validation, adversative and double-negation handling, and exact phrase-specific sense exclusions.

Run:

```bash
python validator/validate_hospitality_os.py <canonical-folder-or-zip>
python tests/run_known_mutations.py <canonical-folder>
```
