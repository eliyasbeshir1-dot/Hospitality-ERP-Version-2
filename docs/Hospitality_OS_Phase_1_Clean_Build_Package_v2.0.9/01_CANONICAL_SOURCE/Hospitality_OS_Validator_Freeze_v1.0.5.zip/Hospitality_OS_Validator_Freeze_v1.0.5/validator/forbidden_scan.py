from __future__ import annotations
import re

def bounded(text:str):
    escaped=re.escape(text).replace(r'\ ',r'\s+')
    return re.compile(r'(?<![a-z0-9])'+escaped+r'(?![a-z0-9])',re.I)

SENTENCE_SPLIT=re.compile(r'(?<=[.!?])\s+|[\r\n]+')
ADVERSATIVE_SPLIT=re.compile(r'\s*(?:;|,?\s+\b(?:but|however|yet|nevertheless|nonetheless|except)\b\s+|,\s*\b(?:while|although)\b\s+)\s*',re.I)
AUX_NOT=re.compile(r'\b(?:do|does|did|must|may|should|can|could|shall|will)\s+not\s+([a-z]+)\b',re.I)
POST_PATTERNS=[re.compile(x,re.I) for x in [
 r'\b(?:is|are|remain|remains)\s+(?:not\s+present|excluded|prohibited|deferred|outside\s+phase\s+1)\b',
 r'\b(?:has|have)\s+no\s+phase\s+1\b',r'\b(?:named|documented)\s+only\b',
 r'\bactivates?\s+with\s+(?:the\s+)?phase\s+2\b',r'\boutside\s+phase\s+1\b',
 r'\bnamed\s+only\b.{0,100}\bphase\s+2\b.{0,100}\b(?:contract|documentation)\b']]

def split_clauses(text:str):
    for sentence in [x.strip() for x in SENTENCE_SPLIT.split(text) if x.strip()]:
        for clause in [x.strip(' ,') for x in ADVERSATIVE_SPLIT.split(sentence) if x.strip(' ,')]:
            yield clause

def prepare(rules,active_ids):
    neg=[bounded(x) for x in sorted(rules.get('negation_markers',[]),key=len,reverse=True) if x.lower() not in {'future','later phases'}]
    verbs={x.lower() for x in rules.get('positive_obligation_verbs',[])}
    verb_rx=[bounded(x) for x in verbs]
    neutral={x.lower() for x in rules.get('occurrence_policy',{}).get('double_negation_neutralizers',[])}
    senses={}
    errors=[]
    for item in rules.get('term_sense_exclusions',[]):
        term=item.get('term','').lower();ids=item.get('allowed_requirement_ids',[]);patterns=item.get('allowed_patterns',[])
        if not ids:errors.append(('SENSE_ALLOWLIST_EMPTY',term))
        if not patterns:errors.append(('SENSE_PATTERN_EMPTY',term))
        for rid in ids:
            if rid not in active_ids:errors.append(('SENSE_ALLOWLIST_ID_MISSING',f'{term}:{rid}'))
        ex=item.get('example')
        if ex not in active_ids:errors.append(('SENSE_EXAMPLE_ID_MISSING',f'{term}:{ex}'))
        senses.setdefault(term,[]).append({'ids':set(ids),'allowed':[re.compile(x,re.I) for x in patterns],'blocked':[re.compile(x,re.I) for x in item.get('blocked_patterns',[])]})
    return {'neg':neg,'verbs':verb_rx,'verb_words':verbs,'neutral':neutral,'senses':senses,'errors':errors}

def sense_allowed(rid,term,clause,prepared):
    for item in prepared['senses'].get(term.lower(),[]):
        if rid in item['ids'] and any(rx.search(clause) for rx in item['allowed']) and not any(rx.search(clause) for rx in item['blocked']):
            return True
    return False

def occurrence_negated(clause,match,prepared):
    prefix=clause[:match.start()]
    for m in AUX_NOT.finditer(prefix):
        if m.group(1).lower() in prepared['neutral']:
            return False
    candidates=[]
    for rx in prepared['neg']:
        candidates.extend(rx.finditer(clause,0,match.start()))
    # Treat "does not <positive verb>" as one direct negative, except neutralizers.
    for m in AUX_NOT.finditer(prefix):
        if m.group(1).lower() in prepared['verb_words'] and m.group(1).lower() not in prepared['neutral']:
            candidates.append(m)
    if candidates:
        neg=max(candidates,key=lambda x:x.end())
        between=clause[neg.end():match.start()]
        if not any(rx.search(between) for rx in prepared['verbs']):
            return True
    tail=clause[match.end():match.end()+220]
    if any(rx.search(tail) for rx in POST_PATTERNS):
        return True
    return False

def scan_text(rid,text,rules,prepared):
    findings=[]
    for clause in split_clauses(text):
        for domain,terms in rules.get('forbidden_positive_obligations',{}).items():
            for term in sorted(terms,key=len,reverse=True):
                for match in bounded(term).finditer(clause):
                    if not sense_allowed(rid,term,clause,prepared) and not occurrence_negated(clause,match,prepared):
                        findings.append({'requirement_id':rid,'domain':domain,'term':term,'clause':clause,'start':match.start()})
    return findings

def scan_requirements(requirements,rules):
    active={r['id'] for r in requirements};prepared=prepare(rules,active);findings=[]
    for r in requirements:
        texts=[r.get('required_behavior','')]+[c.get('exact_clause_text','') for c in r.get('clauses',[])]
        for text in texts:findings.extend(scan_text(r['id'],text,rules,prepared))
    return prepared['errors'],findings
