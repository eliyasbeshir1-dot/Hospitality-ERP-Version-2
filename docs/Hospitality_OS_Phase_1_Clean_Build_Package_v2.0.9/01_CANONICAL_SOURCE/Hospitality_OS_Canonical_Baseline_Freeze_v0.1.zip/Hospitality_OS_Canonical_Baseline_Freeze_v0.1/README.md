# Hospitality OS Canonical Baseline Freeze v0.1

This is an intermediate governance artifact, not a build package.

Use it to:

1. Verify the authenticated v2.0.3/v2.0.4 lineage.
2. Confirm zero-semantic-change mechanical import into canonical JSON.
3. Provide Claude with the blank anti-anchored clause-level review template.
4. Start two independent semantic dependency reviews.
5. Keep import and corrective amendment as separate operations.

Do not:

- create M0R;
- create a database or migration;
- write application code;
- treat `dependency_graph_imported.json` as approved;
- patch the frozen inputs directly.
