# Known Baseline Discrepancies — Logged, Not Repaired

This freeze intentionally preserves the authenticated v2.0.4 machine-readable records without correction.

## Logged observations

1. **D-113 provenance mismatch**
   - v2.0.4 Source of Truth: `v2.0.4`
   - v2.0.4 decision YAML: `v2.0.3`
   - Claude reports D-113 was introduced in v2.0.3, so the YAML value is the likely correct provenance.
   - No correction is applied during mechanical import.

2. **Potential active `journal entr|campaign` semantic match**
   - Claude observed one surviving match in active requirements.
   - It may be a correctly fenced deferral statement or a residual positive obligation.
   - Classification is deferred to the independent clause-level review.

3. **Imported dependency graph**
   - Preserved exactly from v2.0.4.
   - Known to require independent semantic review; broad revalidation spans must be earned clause by clause.

4. **v2.0.4 Codex findings**
   - The authenticated review remains the governing finding set for later explicit amendments.
   - No finding is silently corrected in this freeze.
