# Blind Mutation Testing Protocol

## Ownership

- ChatGPT authors and freezes the validator.
- Claude authors blind mutation packs after the validator checksum is published.
- ChatGPT runs each pack unchanged.
- Codex may add independent mutations during Package M0.

## Two-round cap

### Round 1
Misses caused by validator implementation defects or missing already-approved constraints are blockers. Repair and refreeze the validator.

### Round 2
A completely fresh blind pack is required.

After Round 2:

- implementation misses remain blockers;
- misses requiring genuinely new semantic doctrine are recorded as validator-coverage limits for Codex;
- no third blind-pack cycle occurs unless Codex identifies a P0 validator defect.

## Required mutation classes

The blind packs must include both:

- structural corruptions;
- structurally perfect but semantically false records.

The pack format and expected failure signatures will be frozen after the canonical dependency review.
