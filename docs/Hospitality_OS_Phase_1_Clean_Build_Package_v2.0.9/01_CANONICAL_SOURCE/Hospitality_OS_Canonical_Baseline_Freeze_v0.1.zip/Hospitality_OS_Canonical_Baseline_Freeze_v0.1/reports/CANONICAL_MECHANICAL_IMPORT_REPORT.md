# Canonical Mechanical Import Report

**Result:** PASS  
**Baseline:** v2.0.4 current content plus v2.0.3 historical disposition evidence  
**Import mode:** Mechanical structure conversion only  
**Corrective amendments applied:** 0

## Summary

| Check | Result |
|---|---:|
| Missing records | 0 |
| Duplicate records | 0 |
| Unexpected records | 0 |
| Semantic changes during import | 0 |
| Active requirements imported | 294 |
| Decisions imported | 118 |
| Original requirement dispositions imported | 500 |
| Original decision dispositions imported | 100 |

## Register-level semantic hashes

| Register | Records | Source semantic SHA-256 | Imported JSON semantic SHA-256 | Changes |
|---|---:|---|---|---:|
| `decisions` | 118 | `7e1c60be3f29f3ec699cdd2a1b63480c20f73307253e2e8ea31027b6ba8855b1` | `7e1c60be3f29f3ec699cdd2a1b63480c20f73307253e2e8ea31027b6ba8855b1` | 0 |
| `requirements` | 294 | `5fd7a3906304dd60344bb91ad4e2a0e8e9254021043253f74f66d03ba10082f4` | `5fd7a3906304dd60344bb91ad4e2a0e8e9254021043253f74f66d03ba10082f4` | 0 |
| `dependency_graph_imported` | 294 | `d39d860f94d29765fafb829f22e9931aa63418fa1bbebdda348f114259f79914` | `d39d860f94d29765fafb829f22e9931aa63418fa1bbebdda348f114259f79914` | 0 |
| `journeys` | 16 | `6e246e5ee67fe59c0db3666dc7959218934d91bea29a03b75eebab746a1fd800` | `6e246e5ee67fe59c0db3666dc7959218934d91bea29a03b75eebab746a1fd800` | 0 |
| `state_machines` | 12 | `1a8431029f5edfc14d3a1f225446cf51c29ef79855f03508724bf8b1b1551d5d` | `1a8431029f5edfc14d3a1f225446cf51c29ef79855f03508724bf8b1b1551d5d` | 0 |
| `phase_boundaries` | None | `99ebd06154a6d569bbcc01583b3fcbcaa372e9297270860c9b173406cb75c5dd` | `99ebd06154a6d569bbcc01583b3fcbcaa372e9297270860c9b173406cb75c5dd` | 0 |
| `m5_ownership` | None | `6d5a1d209c2efac7017671629579874f91019c171a36818a273b5d0477097ec8` | `6d5a1d209c2efac7017671629579874f91019c171a36818a273b5d0477097ec8` | 0 |
| `negative_controls` | 44 | `fffc3bcc60e7a72017bbb2abb8c21c446c27b6dad7e0f9b15e09a320d10eb99e` | `fffc3bcc60e7a72017bbb2abb8c21c446c27b6dad7e0f9b15e09a320d10eb99e` | 0 |
| `non_regression_rules` | 96 | `f5bdccfc58856d1aeccb29519457289d65201dc8116d3f756d565a0b03a83f5c` | `f5bdccfc58856d1aeccb29519457289d65201dc8116d3f756d565a0b03a83f5c` | 0 |
| `review_questions` | 14 | `0aab6305b5c68bfbccf56856d285137b8ab4740f3e9a3fb50748f6259598abe2` | `0aab6305b5c68bfbccf56856d285137b8ab4740f3e9a3fb50748f6259598abe2` | 0 |
| `forbidden_surface_rules` | None | `9cf64ab9a8218d9a4ba45ba76f6e1a93f4dcdeb1b968e9015e0d4dc21ac13c06` | `9cf64ab9a8218d9a4ba45ba76f6e1a93f4dcdeb1b968e9015e0d4dc21ac13c06` | 0 |
| `events` | 80 | `3cd71e75d1720e23f1b22f225fd6516a3c26e2d206d52ba25ff8f6faac1d61e5` | `3cd71e75d1720e23f1b22f225fd6516a3c26e2d206d52ba25ff8f6faac1d61e5` | 0 |
| `implementation_manifest` | None | `49a49a5552153e64cb85c8a76b437c232ffa4c6217fbc3b3c431b95e6e7ed1fe` | `49a49a5552153e64cb85c8a76b437c232ffa4c6217fbc3b3c431b95e6e7ed1fe` | 0 |
| `canonical_registry_imported` | None | `ba00bbe85436e7aa232051e9e83cb3c3299715b94fc126a3dd05d9e803047e82` | `ba00bbe85436e7aa232051e9e83cb3c3299715b94fc126a3dd05d9e803047e82` | 0 |
| `original_requirement_dispositions` | 500 | `442f298e93e129171bcc0c159c4bab488b80733ca41ae01f0c0e7ad4a3951a41` | `442f298e93e129171bcc0c159c4bab488b80733ca41ae01f0c0e7ad4a3951a41` | 0 |
| `original_decision_dispositions` | 100 | `3ea20573e927e9833d5862c6559de78285a062d861fe6f99df48aac7d93b06fc` | `3ea20573e927e9833d5862c6559de78285a062d861fe6f99df48aac7d93b06fc` | 0 |

## Boundary

`canonical/dependency_graph_imported.json` preserves the v2.0.4 dependency representation exactly. It is **not approved as semantically correct**. The next stage is an independent clause-level dependency and gate disposition review by ChatGPT and Claude using blank structures.
