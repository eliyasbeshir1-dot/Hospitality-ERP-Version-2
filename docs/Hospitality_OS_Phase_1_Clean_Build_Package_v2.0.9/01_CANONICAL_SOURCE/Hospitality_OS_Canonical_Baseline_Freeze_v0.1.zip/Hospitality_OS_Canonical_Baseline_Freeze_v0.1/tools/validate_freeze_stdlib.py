#!/usr/bin/env python3
"""Standard-library validator for Hospitality OS Canonical Baseline Freeze v0.1."""

from __future__ import annotations
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def fail(signature: str, detail: str) -> None:
    print(f"FAIL {signature}: {detail}", file=sys.stderr)
    raise SystemExit(1)

def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail("JSON_PARSE_FAILURE", f"{rel}: {exc}")

def canonical_bytes(obj: object) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")

def semantic_hash(obj: object) -> str:
    return hashlib.sha256(canonical_bytes(obj)).hexdigest()

def unique_ids(records, key, expected, signature):
    ids = [r[key] for r in records]
    if len(ids) != expected:
        fail(signature, f"expected {expected}, found {len(ids)}")
    if len(set(ids)) != expected:
        fail(signature, "duplicate IDs detected")
    return set(ids)

def verify_checksum_manifest():
    manifest = ROOT / "SHA256SUMS.txt"
    if not manifest.exists():
        fail("CHECKSUM_MANIFEST_MISSING", "SHA256SUMS.txt not found")
    rows = []
    for line in manifest.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        m = re.match(r"^([a-f0-9]{64})  \./(.+)$", line)
        if not m:
            fail("CHECKSUM_ROW_MALFORMED", line)
        rows.append((m.group(1), m.group(2)))
    seen = set()
    for expected, rel in rows:
        if rel in seen:
            fail("CHECKSUM_DUPLICATE_PATH", rel)
        seen.add(rel)
        path = ROOT / rel
        if not path.exists():
            fail("CHECKSUM_FILE_MISSING", rel)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            fail("CHECKSUM_MISMATCH", rel)
    physical = {
        str(p.relative_to(ROOT)).replace("\\", "/")
        for p in ROOT.rglob("*")
        if p.is_file() and p.name != "SHA256SUMS.txt"
    }
    if seen != physical:
        fail("CHECKSUM_SET_MISMATCH", f"listed={len(seen)} physical={len(physical)}")

def main() -> int:
    lineage = load_json("LINEAGE_MANIFEST.json")
    content_root = load_json("CANONICAL_CONTENT_ROOT.json")
    import_report = load_json("reports/IMPORT_REPORT.json")
    req = load_json("canonical/requirements.json")
    dep = load_json("canonical/dependency_graph_imported.json")
    dec = load_json("canonical/decisions.json")
    journeys = load_json("canonical/journeys.json")
    states = load_json("canonical/state_machines.json")
    controls = load_json("canonical/negative_controls.json")
    rules = load_json("canonical/non_regression_rules.json")
    questions = load_json("canonical/review_questions.json")
    orig_req = load_json("canonical/original_requirement_dispositions.json")
    orig_dec = load_json("canonical/original_decision_dispositions.json")
    blank = load_json("review_templates/blank_clause_level_dependency_disposition.json")

    if lineage["lineage"][0]["zip_sha256"] != "abda9bac8cb3bb52bbccfbcb258f16ffba29faf1e18190dfb6f0cdbaaa773583":
        fail("V204_LINEAGE_HASH_MISMATCH", "unexpected v2.0.4 lineage hash")
    if lineage["lineage"][1]["zip_sha256"] != "2d5564069facd4657c0c7b90987ea9ae19eb0cd7bd689a368e8d10f23dd5e888":
        fail("V203_LINEAGE_HASH_MISMATCH", "unexpected v2.0.3 lineage hash")

    req_ids = unique_ids(req["requirements"], "id", 294, "ACTIVE_REQUIREMENT_COUNT_OR_DUPLICATE")
    dep_ids = unique_ids(dep["requirements"], "id", 294, "DEPENDENCY_COUNT_OR_DUPLICATE")
    if req_ids != dep_ids:
        fail("REQUIREMENT_DEPENDENCY_SET_MISMATCH", f"requirements={len(req_ids)} dependencies={len(dep_ids)}")

    unique_ids(dec["decisions"], "id", 118, "DECISION_COUNT_OR_DUPLICATE")
    unique_ids(journeys["mandatory_journey_slices"], "id", 16, "JOURNEY_COUNT_OR_DUPLICATE")
    unique_ids(states["state_machines"], "id", 12, "STATE_MACHINE_COUNT_OR_DUPLICATE")
    unique_ids(controls["controls"], "id", 44, "NEGATIVE_CONTROL_COUNT_OR_DUPLICATE")
    unique_ids(rules["rules"], "id", 96, "NON_REGRESSION_COUNT_OR_DUPLICATE")
    if len(questions["questions"]) != 14:
        fail("M0_QUESTION_COUNT_MISMATCH", str(len(questions["questions"])))

    orig_req_ids = unique_ids(orig_req["rows"], "Requirement ID", 500, "ORIGINAL_REQUIREMENT_DISPOSITION_FAILURE")
    orig_dec_ids = unique_ids(orig_dec["rows"], "Decision ID", 100, "ORIGINAL_DECISION_DISPOSITION_FAILURE")

    blank_ids = unique_ids(blank["requirements"], "requirement_id", 294, "BLANK_REVIEW_TEMPLATE_SET_FAILURE")
    if blank_ids != req_ids:
        fail("BLANK_REVIEW_TEMPLATE_SET_FAILURE", "blank reviewer set differs from canonical requirements")

    semantic_entries = content_root["semantic_entries"]
    for entry in semantic_entries:
        obj = load_json(entry["file"])
        if semantic_hash(obj) != entry["semantic_sha256"]:
            fail("CANONICAL_SEMANTIC_HASH_MISMATCH", entry["file"])
    root_material = {
        "baseline_version": content_root["baseline_version"],
        "semantic_entries": semantic_entries,
    }
    if semantic_hash(root_material) != content_root["canonical_content_root_sha256"]:
        fail("CANONICAL_CONTENT_ROOT_MISMATCH", "root hash does not recompute")
    if blank["review_metadata"]["lineage_baseline_sha256"] != content_root["canonical_content_root_sha256"]:
        fail("REVIEW_TEMPLATE_BASELINE_MISMATCH", "blank template references another content root")

    if import_report["summary"]["semantic_changes"] != 0:
        fail("IMPORT_SEMANTIC_CHANGE_DETECTED", str(import_report["summary"]["semantic_changes"]))

    verify_checksum_manifest()
    print("PASS CANONICAL_BASELINE_FREEZE_VALID")
    print(json.dumps({
        "requirements": len(req_ids),
        "decisions": 118,
        "original_requirement_dispositions": len(orig_req_ids),
        "original_decision_dispositions": len(orig_dec_ids),
        "canonical_content_root_sha256": content_root["canonical_content_root_sha256"],
    }, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
