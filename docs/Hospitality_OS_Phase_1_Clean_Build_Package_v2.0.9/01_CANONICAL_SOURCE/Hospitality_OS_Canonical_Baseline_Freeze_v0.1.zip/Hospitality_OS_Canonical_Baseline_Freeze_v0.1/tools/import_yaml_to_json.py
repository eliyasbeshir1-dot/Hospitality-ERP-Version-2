#!/usr/bin/env python3
"""Mechanical YAML-to-JSON importer for Hospitality OS canonical baseline.

This tool is intentionally separate from corrective amendment logic.
It requires PyYAML==6.0.2 and performs no product or dependency decisions.
"""

from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import yaml

def canonical_bytes(obj: object) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")

def semantic_hash(obj: object) -> str:
    return hashlib.sha256(canonical_bytes(obj)).hexdigest()

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_yaml", type=Path)
    parser.add_argument("output_json", type=Path)
    args = parser.parse_args()

    source_obj = yaml.safe_load(args.source_yaml.read_text(encoding="utf-8"))
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(
        json.dumps(source_obj, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    output_obj = json.loads(args.output_json.read_text(encoding="utf-8"))

    source_hash = semantic_hash(source_obj)
    output_hash = semantic_hash(output_obj)
    print(json.dumps({
        "source": str(args.source_yaml),
        "output": str(args.output_json),
        "source_semantic_sha256": source_hash,
        "output_semantic_sha256": output_hash,
        "semantic_changes": 0 if source_hash == output_hash else 1,
    }, indent=2))
    return 0 if source_hash == output_hash else 1

if __name__ == "__main__":
    raise SystemExit(main())
