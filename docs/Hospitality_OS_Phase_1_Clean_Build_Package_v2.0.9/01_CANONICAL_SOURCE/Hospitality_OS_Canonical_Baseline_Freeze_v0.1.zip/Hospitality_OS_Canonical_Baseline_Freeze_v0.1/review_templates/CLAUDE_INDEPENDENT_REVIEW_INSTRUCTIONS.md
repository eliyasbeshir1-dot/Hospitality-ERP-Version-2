# Independent Clause-Level Dependency Review Instructions

## Anti-anchoring rule

The reviewer receives:

- frozen canonical requirement text;
- product and architecture definitions;
- milestone definitions;
- this blank structure.

The reviewer must not receive ChatGPT's gate assignments, clause splits, rationales or final dispositions before completing the independent pass.

## Review unit

The atomic review unit is a **behavioral clause**, not the full requirement row.

Split a requirement when independent clauses:

- begin at different gates;
- require different prerequisite artifacts;
- need different journey/test evidence;
- contain a future-domain obligation mixed with a valid Phase 1 behavior.

## Required judgment for every clause

Record:

1. exact clause text;
2. whether a successor requirement ID is needed;
3. introducing gate;
4. prerequisite components and requirements;
5. artifacts available at introduction;
6. executable gate-local behavior;
7. later behavior;
8. revalidation gates;
9. specific journey links;
10. specific engineering-test links;
11. deferred-domain risk;
12. rationale and confidence.

## Important constraints

- Do not use milestone-wide blanket journey links.
- Do not choose `revalidate everywhere` without clause-specific justification.
- A journey cannot depend on a requirement introduced at a later gate.
- Broad governance and security rules may revalidate across several gates, but each revalidation must name the concrete later artifact or behavior.
- Requirement counts may change after splitting. Preserve `split_from`, `supersedes` and successor lineage.
- Mark genuine product or architecture conflicts for founder decision instead of forcing a gate assignment.
