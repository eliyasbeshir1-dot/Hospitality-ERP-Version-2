# Canonical Baseline Freeze Report v0.1

## Status

**FROZEN FOR INDEPENDENT DEPENDENCY REVIEW**

This artifact establishes the imported canonical baseline. It does not approve v2.0.4, create M0R, or authorize implementation.

## Authenticated lineage

- v2.0.4 SHA-256: `abda9bac8cb3bb52bbccfbcb258f16ffba29faf1e18190dfb6f0cdbaaa773583`
- v2.0.3 SHA-256: `2d5564069facd4657c0c7b90987ea9ae19eb0cd7bd689a368e8d10f23dd5e888`

## Frozen canonical sets

- Active requirements: **294**
- Decisions: **118**
- Journey slices: **16**
- State machines: **12**
- Negative controls: **44**
- Non-regression rules: **96**
- Original requirement dispositions: **500**
- Original decision dispositions: **100**

## Freeze rules

1. No direct edits to v2.0.3 or v2.0.4.
2. No corrective change is mixed into the import.
3. Every later amendment is a patch with old value, new value, reason, affected IDs and verification.
4. Requirement counts may change after clause splitting; lineage must preserve superseded IDs.
5. The imported dependency graph is evidence only, not approval.
6. Claude receives a blank anti-anchored disposition structure, not ChatGPT's later conclusions.
7. M0R, database creation, migration `0001` and application coding remain prohibited.
